﻿Si vous souhaitez ajouter automatiquement quelques questions sur votre copie locale de l'application web ScreenTest, voici comment faire :
1. Copiez les images du dossier *screens* contenu dans cette archive au dossier *screens* présent à la racine du serveur où vous exécutez l'application.
2. Allez dans votre interface de contrôle de PosgreSQL et exécutez les requêtes suivantes.

INSERT INTO screentest.Question(image, answer0, answer1, answer2, answer3, cat_id, validated) VALUES ('screens/exm01.jpg','Drive','Bullit','Collateral','Reservoir Dogs',1,true);
INSERT INTO screentest.Question(image, answer0, answer1, answer2, answer3, cat_id, validated) VALUES ('screens/exm02.jpg','Pulp Fiction','Wild Hogs','Hairspray','Grease',1,true);
INSERT INTO screentest.Question(image, answer0, answer1, answer2, answer3, cat_id, validated) VALUES ('screens/exm03.jpg','American Psycho','Batman Begins','Equilibrium','The Emoji Movie',1,true);
INSERT INTO screentest.Question(image, answer0, answer1, answer2, answer3, cat_id, validated) VALUES ('screens/exm04.jpg','Batman: The Dark Knight','It','Batman Begins','One Flew Over the Cuckoo''s Nest',1,true);
INSERT INTO screentest.Question(image, answer0, answer1, answer2, answer3, cat_id, validated) VALUES ('screens/exm05.jpg','Avatar','Kingsglaive: Final Fantasy XV','Halo 4: Forward Unto Dawn','Fast & Furious',1,true);
INSERT INTO screentest.Question(image, answer0, answer1, answer2, answer3, cat_id, validated) VALUES ('screens/exm06.jpg','Blade Runner','Riders of the Lost Ark','The Empire Strikes Back','The Expendables 3',1,true);
INSERT INTO screentest.Question(image, answer0, answer1, answer2, answer3, cat_id, validated) VALUES ('screens/exm07.jpg','12 Angry Men','Vertigo','Hot Summer Night','Invasion of the Saucer Men',1,true);
INSERT INTO screentest.Question(image, answer0, answer1, answer2, answer3, cat_id, validated) VALUES ('screens/exm08.jpg','The Lord of the Rings: The Return of the King','The Lord of the Rings: The Fellowship of the Ring','The Lord of the Rings: The Two Towers','Breakin'' 2: Electric Boogaloo',1,true);
INSERT INTO screentest.Question(image, answer0, answer1, answer2, answer3, cat_id, validated) VALUES ('screens/exm09.jpg','Astérix et Obélix : Mission Cléopâtre','Astérix et Obélix contre César','Astérix aux Jeux olympiques','Boule et Bill',1,true);
INSERT INTO screentest.Question(image, answer0, answer1, answer2, answer3, cat_id, validated) VALUES ('screens/exm10.jpg','Citizen Kane','Rear Window','La classe américaine','V for Vendetta',1,true);
INSERT INTO screentest.Question(image, answer0, answer1, answer2, answer3, cat_id, validated) VALUES ('screens/exm11.jpg','Fight Club','The People vs. Larry Flynt','American History X','The Incredible Hulk',1,true);
INSERT INTO screentest.Question(image, answer0, answer1, answer2, answer3, cat_id, validated) VALUES ('screens/exm12.jpg','Shaun of the Dead','Land of the Dead','The World''s End','A Fistful of Fingers',1,true);
INSERT INTO screentest.Question(image, answer0, answer1, answer2, answer3, cat_id, validated) VALUES ('screens/exm13.jpg','Shichinin no Samurai (Seven Samurai)','Youjinbou','Genghis Khan','Jingi Naki Tatakai',1,true);
INSERT INTO screentest.Question(image, answer0, answer1, answer2, answer3, cat_id, validated) VALUES ('screens/exg01.jpg','Super Mario Galaxy','Super Mario Sunshine','Banjo-Kazooie: Nuts & Bolts','Bubsy 3D',3,true);
INSERT INTO screentest.Question(image, answer0, answer1, answer2, answer3, cat_id, validated) VALUES ('screens/exg02.jpg','Zelda: The Wand of Gamelon','The Legend of Zelda: Breath of the Wild','The Elder Scrolls V: Skyrim','Plumbers Don''t Wear Ties',3,true);
INSERT INTO screentest.Question(image, answer0, answer1, answer2, answer3, cat_id, validated) VALUES ('screens/exg03.jpg','Uncharted 2: Among Thieves','Tomb Raider: Legend','Assassin''s Creed: Revelations','Heavy Rain',3,true);
INSERT INTO screentest.Question(image, answer0, answer1, answer2, answer3, cat_id, validated) VALUES ('screens/exg04.jpg','Galaga','Space Invaders','Frogger 2: Swampy''s Revenge','Asteroids',3,true);
INSERT INTO screentest.Question(image, answer0, answer1, answer2, answer3, cat_id, validated) VALUES ('screens/exg05.jpg','Halo 3','Halo 2','Halo 3: ODST','Chex Quest',3,true);
INSERT INTO screentest.Question(image, answer0, answer1, answer2, answer3, cat_id, validated) VALUES ('screens/exa01.jpg','Toaru Kagaku no Railgun S','Serial Experiments Lain','Neon Genesis Evangelion','Sidonia no Kishi (Knights of Sidonia)',4,true);
INSERT INTO screentest.Question(image, answer0, answer1, answer2, answer3, cat_id, validated) VALUES ('screens/exa02.jpg','Redline','Space☆Dandy','Afro Samurai','Wacky Races',4,true);
INSERT INTO screentest.Question(image, answer0, answer1, answer2, answer3, cat_id, validated) VALUES ('screens/exa03.jpg','One Punch Man','Dragon Ball Kai','Mob Psycho 100','Mind Game',4,true);
INSERT INTO screentest.Question(image, answer0, answer1, answer2, answer3, cat_id, validated) VALUES ('screens/exa04.jpg','Nisemonogatari','Bakemonogatari','Maria†Holic','Dansai Bunri no Crime Edge',4,true);
INSERT INTO screentest.Question(image, answer0, answer1, answer2, answer3, cat_id, validated) VALUES ('screens/exa05.jpg','Katanagatari','Sayonara Zetsubou-sensei','Baku','Witchblade',4,true);
INSERT INTO screentest.Question(image, answer0, answer1, answer2, answer3, cat_id, validated) VALUES ('screens/exa06.jpg','Top wo Nerae! Gunbuster','Tengen Toppa Gurren Lagann','Mobile Fighter G Gundam','Otaku no Video',4,true);
INSERT INTO screentest.Question(image, answer0, answer1, answer2, answer3, cat_id, validated) VALUES ('screens/exa07.jpg','Mushishi Zoku Shou 2nd Season','Kino no Tabi: The Beautiful World','Ookami Kodomo no Ame to Yuki','Yama no Susume 2nd Season',4,true);

3. Si vous voulez vérifier que les images ont été bien incluses, vous pouvez soit lancer un quiz Cinéma, Jeu Vidéo ou Dessin Animé (Séries est laissé vide volontairement pour montrer que l'application sait s'occuper d'une BDD vide). Vous pouvez aussi aller à *query.php*, mais attention à ne pas vous spoiler les réponses !

Bon jeu !